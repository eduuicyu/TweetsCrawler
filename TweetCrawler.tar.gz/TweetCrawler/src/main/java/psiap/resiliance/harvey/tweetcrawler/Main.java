package psiap.resiliance.harvey.tweetcrawler;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import twitter4j.TwitterException;

public class Main {

    //public static final String TWITTER_ACCOUNT_INFO_FILE = "TwitterAccountInfo2.properties";

    public static void main(String[] args) throws IOException {
	long maxId = 0;
	int fileSeq = 1;
	int accountSeq = 1;
	while(true){
	    Properties p = new Properties();
            try (FileInputStream fis = new FileInputStream("TwitterAccountInfo"+accountSeq+".properties")) {
            	p.load(fis);
            }
            TwitterCrawler crawler = new TwitterCrawler(p);
            try(FileTweetSaver saver = new FileTweetSaver("output"+fileSeq+".json")){
		System.out.println(""+accountSeq);
		while(true){
		    try {
                        maxId = crawler.searchRadius(maxId, 29.7604, -95.3698, 500, false, saver);
                    }catch(TwitterException te){
	    	        fileSeq++;
		        accountSeq++;
		        if(accountSeq==8){
		            accountSeq=1;		
		        }
                        break;
	            }
	        }
	    }	    
	    
	}
        
    }

}
